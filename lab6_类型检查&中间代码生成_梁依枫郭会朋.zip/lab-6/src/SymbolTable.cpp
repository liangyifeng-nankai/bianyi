#include "SymbolTable.h"
#include <iostream>
#include <sstream>
#include "Type.h"
SymbolEntry::SymbolEntry(Type *type, int kind) 
{
    this->type = type;
    this->kind = kind;
}

ConstantSymbolEntry::ConstantSymbolEntry(Type *type, int value) : SymbolEntry(type, SymbolEntry::CONSTANT)
{
    this->value = value;
}

std::string ConstantSymbolEntry::toStr()
{
    std::ostringstream buffer;
    buffer << value;
    return buffer.str();
}

IdentifierSymbolEntry::IdentifierSymbolEntry(Type *type, std::string name, int scope) : SymbolEntry(type, SymbolEntry::VARIABLE), name(name)
{
    this->scope = scope;
    addr = nullptr;
}

std::string IdentifierSymbolEntry::toStr()
{
    return "@" + name;
}

TemporarySymbolEntry::TemporarySymbolEntry(Type *type, int label) : SymbolEntry(type, SymbolEntry::TEMPORARY)
{
    this->label = label;
}

std::string TemporarySymbolEntry::toStr()
{
    std::ostringstream buffer;
    buffer << "%t" << label;
    return buffer.str();
}

SymbolTable::SymbolTable()
{
    prev = nullptr;
    level = 0;
}

SymbolTable::SymbolTable(SymbolTable *prev)
{
    this->prev = prev;
    this->level = prev->level + 1;
}

/*
    Description: lookup the symbol entry of an identifier in the symbol table
    Parameters: 
        name: identifier name
    Return: pointer to the symbol entry of the identifier

    hint:
    1. The symbol table is a stack. The top of the stack contains symbol entries in the current scope.
    2. Search the entry in the current symbol table at first.
    3. If it's not in the current table, search it in previous ones(along the 'prev' link).
    4. If you find the entry, return it.
    5. If you can't find it in all symbol tables, return nullptr.
*/
SymbolEntry* SymbolTable::lookup(std::string name)
{
    // Todo
    SymbolTable* table = this;
    while (table != nullptr)
        //如果找到了就返回，没找到就返回上一层继续
        if (table->symbolTable.find(name) != table->symbolTable.end()) {
            return table->symbolTable[name];
        } else {
            table = table->prev;
        }
    //没找到返回null
    return nullptr;
}
bool IdentifierSymbolEntry::addfunc(SymbolEntry* newfunc){
    if(!newfunc->getType()->isFunc())
        return false;
    //暂时只考虑所有的参数都是int与float
    FunctionType* newfunctype = (FunctionType*)(newfunc->getType());
    int paramsnum = newfunctype->getParams().size();
    if(((FunctionType*)(this->getType()))->getParams().size()==paramsnum)
        return false;
    for(int i =0;i<allfunc.size();i++){
        if(((FunctionType*)(allfunc[i]->getType()))->getParams().size()==paramsnum)
            return false;
    }
    allfunc.push_back(newfunc);
    return true;
}
// install the entry into current symbol table.
bool SymbolTable::install(std::string name, SymbolEntry* entry)
{	
    //可能存在重定义还没有处理
    if (this->symbolTable.find(name) != this->symbolTable.end()) {
        SymbolEntry* se = this->symbolTable[name];
        if(se->getType()->isFunc())
            return ((IdentifierSymbolEntry*)(se))->addfunc(entry);
        return false;
    } else {
        this->symbolTable[name] = entry;
        return true;
    }
}

int SymbolTable::counter = 0;
static SymbolTable t;
SymbolTable *identifiers = &t;
SymbolTable *globals = &t;
