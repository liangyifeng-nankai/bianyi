#include "Type.h"
#include <sstream>
#include "Ast.h"
IntType TypeSystem::commonInt = IntType(32);
IntType TypeSystem::commonBool = IntType(1);
VoidType TypeSystem::commonVoid = VoidType();
FloatType TypeSystem::commonFloat = FloatType(32);
IntType TypeSystem::commonconstInt = IntType(32,true);
FloatType TypeSystem::commonconstFloat = FloatType(32,true);

Type* TypeSystem::intType = &commonInt;
Type* TypeSystem::voidType = &commonVoid;
Type* TypeSystem::boolType = &commonBool;
Type* TypeSystem::floatType = &commonFloat;
Type* TypeSystem::constfloatType = &commonconstFloat;
Type* TypeSystem::constintType = &commonconstInt;

std::string IntType::toStr()
{    
    std::ostringstream buffer;
    buffer << "i" << size;
    return buffer.str();
}

std::string VoidType::toStr()
{
    return "void";
}
std::string FloatType::toStr()
{
   
    return "float";
}
std::string ArrayType::toStr()
{
    std::ostringstream buffer;
    buffer <<"arr "<< type->toStr() ;
    //
    return buffer.str();
}
void ArrayType::output(int level){dim->output(level);}
std::string FunctionType::toStr()
{
     std::ostringstream buffer;
    buffer << returnType->toStr() << "(";
    std::vector<Type*>::iterator it; 
    it=paramsType.begin();
    if(it!=paramsType.end()){
 	for(;it+1!=paramsType.end();it++){
	    buffer<<(*it)->toStr();
	    buffer<<",";
	}
	buffer<<(*it)->toStr();
    }
    buffer<<")";
    return buffer.str();
}

std::string PointerType::toStr()
{
    std::ostringstream buffer;
    buffer << valueType->toStr() << "*";
    return buffer.str();
}
