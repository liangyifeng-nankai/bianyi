#include "Ast.h"
#include "SymbolTable.h"
#include "Unit.h"
#include "Instruction.h"
#include "IRBuilder.h"
#include <string>
#include "Type.h"
extern Unit unit;
extern FILE *yyout;
extern BasicBlock* globalblock;
int Node::counter = 0;
IRBuilder* Node::builder = nullptr;

Node::Node()
{
    seq = counter++;
}

void Node::backPatch(std::vector<Instruction*> &list, BasicBlock*bb)
{
    for(auto &inst:list)
    {
        if(inst->isCond())
            dynamic_cast<CondBrInstruction*>(inst)->setTrueBranch(bb);
        else if(inst->isUncond())
            dynamic_cast<UncondBrInstruction*>(inst)->setBranch(bb);
    }
}

std::vector<Instruction*> Node::merge(std::vector<Instruction*> &list1, std::vector<Instruction*> &list2)
{
    std::vector<Instruction*> res(list1);
    res.insert(res.end(), list2.begin(), list2.end());
    return res;
}

void Ast::genCode(Unit *unit)
{
    IRBuilder *builder = new IRBuilder(unit);
    Node::setIRBuilder(builder);
    root->genCode();
}

void FunctionDef::genCode()
{
    fprintf(stderr,"funcdef:%s\n",se->toStr().c_str());
    Unit *unit = builder->getUnit();
    Function *func = new Function(unit, se);
    BasicBlock *entry = func->getEntry();
    // set the insert point to the entry basicblock of this function.
    builder->setInsertBB(entry);
    if (decl)
        decl->genCode();
    if (stmt)
        stmt->genCode();

    /**
     * Construct control flow graph. You need do set successors and predecessors for each basic block.
     * Todo
    */
    for (auto block = func->begin(); block != func->end(); block++) {
        //获取该块的最后一条指令
        Instruction* i = (*block)->begin();
        Instruction* last = (*block)->rbegin();
        while (i != last) {
            if (i->isCond() || i->isUncond()) {
                (*block)->remove(i);
            }
            i = i->getNext();
        }
        if (last->isCond()) {
            BasicBlock *truebranch, *falsebranch;
            truebranch =dynamic_cast<CondBrInstruction*>(last)->getTrueBranch();
            falsebranch =dynamic_cast<CondBrInstruction*>(last)->getFalseBranch();
            if (truebranch->empty()) {
                new RetInstruction(nullptr, truebranch);
            } else if (falsebranch->empty()) {
                new RetInstruction(nullptr, falsebranch);
            }
            (*block)->addSucc(truebranch);
            (*block)->addSucc(falsebranch);
            truebranch->addPred(*block);
            falsebranch->addPred(*block);
        } else if (last->isUncond()) {  
            BasicBlock* dst =dynamic_cast<UncondBrInstruction*>(last)->getBranch();
            (*block)->addSucc(dst);
            dst->addPred(*block);
            if (dst->empty()) {
                if (((FunctionType*)(se->getType()))->getRetType() ==
                    TypeSystem::intType) {
                    new RetInstruction(new Operand(new ConstantSymbolEntry(TypeSystem::intType, 0)),dst);
                } else if (((FunctionType*)(se->getType()))->getRetType() ==TypeSystem::floatType) {
                    new RetInstruction(new Operand(new ConstantSymbolEntry(TypeSystem::floatType, 0)),dst);
                } else if (((FunctionType*)(se->getType()))->getRetType() ==TypeSystem::voidType) {
                    new RetInstruction(nullptr, dst);
                }
            }

        }
        else if (!last->isRet()) {
            if (((FunctionType*)(se->getType()))->getRetType() ==
                TypeSystem::voidType) {
                new RetInstruction(nullptr, *block);
            }
            else
                fprintf(stderr,"函数缺少返回值");
        }
    }
    for (auto it = func->begin(); it != func->end(); it++) {
        auto block = *it;
        bool flag = false;
        for (auto i = block->begin(); i != block->end(); i = i->getNext()) {
            if (flag) {
                block->remove(i);
                delete i;
                continue;
            }
            if (i->isRet())
                flag = true;
        }
        //删除后继节点
        if (flag) {
            while (block->succ_begin() != block->succ_end()) {
                auto b = *(block->succ_begin());
                block->removeSucc(b);
                b->removePred(block);
            }
        }
    }
    while (true) {
        bool flag = false;
        for (auto it = func->begin(); it != func->end(); it++) {
            auto block = *it;
            if (block == func->getEntry())
                continue;
            if (block->getNumOfPred() == 0) {
                delete block;
                flag = true;
                break;
            }
        }
        if (!flag)
            break;
    }
    if(se->toStr()=="@main"){
        entry->intoentry(globalblock);
    }
    fprintf(stderr,"funcdef:%s\n",se->toStr().c_str());
}

void BinaryExpr::genCode()
{
    BasicBlock *bb = builder->getInsertBB();
    Function *func = bb->getParent();
    if (op == AND)
    {
        BasicBlock *trueBB = new BasicBlock(func);  // if the result of lhs is true, jump to the trueBB.
        expr1->genCode();
        backPatch(expr1->trueList(), trueBB);
        builder->setInsertBB(trueBB);               // set the insert point to the trueBB so that intructions generated by expr2 will be inserted into it.
        expr2->genCode();
        true_list = expr2->trueList();
        false_list = merge(expr1->falseList(), expr2->falseList());
    }
    else if(op == OR)
    {
        // Todo
        BasicBlock* trueBB = new BasicBlock(func);
        expr1->genCode();
        //第一个表达式错误跳转到第二个表达式
        backPatch(expr1->falseList(), trueBB);
        builder->setInsertBB(trueBB);
        expr2->genCode();
        ////真分支合并
        true_list = merge(expr1->trueList(), expr2->trueList());
        false_list = expr2->falseList();
    }
    else if(op >= LESS && op <= NOTEQUAL)
    {
        // Todo
        expr1->genCode();
        expr2->genCode();
        Operand* src1 = expr1->getOperand();
        Operand* src2 = expr2->getOperand();
        if(src1->getType()->isFunc()){

        }
        else if (((IntType*)(src1->getType()))->getsize() == 1) {
            Operand* dst = new Operand(new TemporarySymbolEntry(
                TypeSystem::intType, SymbolTable::getLabel()));
            new ZextInstruction(dst, src1, bb);
            src1 = dst;
        }
        if(src1->getType()->isFunc()){

        }
        else if (((IntType*)(src2->getType()))->getsize() == 1) {
            Operand* dst = new Operand(new TemporarySymbolEntry(
                TypeSystem::intType, SymbolTable::getLabel()));
            new ZextInstruction(dst, src2, bb);
            src2 = dst;
        }
        int cmpopcode = -1;
        switch (op) {
            case LESS:
                cmpopcode = CmpInstruction::L;
                break;
            case LESSEQUAL:
                cmpopcode = CmpInstruction::LE;
                break;
            case GREATER:
                cmpopcode = CmpInstruction::G;
                break;
            case GREATEREQUAL:
                cmpopcode = CmpInstruction::GE;
                break;
            case EQUAL:
                cmpopcode = CmpInstruction::E;
                break;
            case NOTEQUAL:
                cmpopcode = CmpInstruction::NE;
                break;
        }
        new CmpInstruction(cmpopcode, dst, src1, src2, bb);
        BasicBlock *truebb, *falsebb, *tempbb;

        truebb = new BasicBlock(func);
        falsebb = new BasicBlock(func);
        tempbb = new BasicBlock(func);
        true_list.push_back(new CondBrInstruction(truebb, tempbb, dst, bb));
        false_list.push_back(new UncondBrInstruction(falsebb, tempbb));
    }
    else if((op >= ADD && op <= DIV)||op==MOD)
    {
        expr1->genCode();
        expr2->genCode();
        Operand *src1 = expr1->getOperand();
        Operand *src2 = expr2->getOperand();
        int opcode;
        switch (op)
        {
        case ADD:
            opcode = BinaryInstruction::ADD;
            break;
        case SUB:
            opcode = BinaryInstruction::SUB;
            break;
        case MUL:
            opcode = BinaryInstruction::MUL;
            break;
        case DIV:
            opcode = BinaryInstruction::DIV;
            break;
        case MOD:
            opcode = BinaryInstruction::MOD;
            break;
        }
        new BinaryInstruction(opcode, dst, src1, src2, bb);
    }
}

void Constant::genCode()
{
    // we don't need to generate code.
}

void Id::genCode()
{
    BasicBlock *bb = builder->getInsertBB();
    Operand *addr = dynamic_cast<IdentifierSymbolEntry*>(symbolEntry)->getAddr();
    //if()
    new LoadInstruction(dst, addr, bb);
}

void IfStmt::genCode()
{
    Function *func;
    BasicBlock *then_bb, *end_bb;

    func = builder->getInsertBB()->getParent();
    then_bb = new BasicBlock(func);
    end_bb = new BasicBlock(func);

    cond->genCode();
    backPatch(cond->trueList(), then_bb);
    backPatch(cond->falseList(), end_bb);

    builder->setInsertBB(then_bb);
    thenStmt->genCode();
    then_bb = builder->getInsertBB();
    new UncondBrInstruction(end_bb, then_bb);

    builder->setInsertBB(end_bb);
}

void IfElseStmt::genCode()
{
     Function* func;
    BasicBlock *then_bb, *else_bb, *end_bb /*, *bb*/;

    func = builder->getInsertBB()->getParent();
    then_bb = new BasicBlock(func);
    else_bb = new BasicBlock(func);
    end_bb = new BasicBlock(func);

    cond->genCode();

    backPatch(cond->trueList(), then_bb);
    backPatch(cond->falseList(), else_bb);

    builder->setInsertBB(then_bb);
    thenStmt->genCode();
    then_bb = builder->getInsertBB();
    new UncondBrInstruction(end_bb, then_bb);

    builder->setInsertBB(else_bb);
    elseStmt->genCode();
    else_bb = builder->getInsertBB();
    new UncondBrInstruction(end_bb, else_bb);

    builder->setInsertBB(end_bb);
}
void DeclStmt::genCode() {
    for(int i =0;i<deflist.size();i++){
        deflist[i]->genCode();
    }
}
void DefStmt::genCode(){
    IdentifierSymbolEntry *se = dynamic_cast<IdentifierSymbolEntry *>(id->getSymPtr());
    if(se->isGlobal())
    {
        Operand *addr;
        SymbolEntry *addr_se;
        addr_se = new IdentifierSymbolEntry(*se);
        addr_se->setType(new PointerType(se->getType()));
        addr = new Operand(addr_se);
        se->setAddr(addr);
        unit.intoGlobal(se);
        
        builder->setInsertBB(globalblock);
        if(expr){
            expr->genCode();
            Operand* src = expr->getOperand();
            new StoreInstruction(addr, src, globalblock);
        }
    }
    else if(se->isLocal()||se->isParam())
    {
        Function *func = builder->getInsertBB()->getParent();
        BasicBlock *entry = func->getEntry();
        Instruction *alloca;
        Operand *addr;
        SymbolEntry *addr_se;
        Type *type;
        type = new PointerType(se->getType());
        addr_se = new TemporarySymbolEntry(type, SymbolTable::getLabel());
        addr = new Operand(addr_se);
        alloca = new AllocaInstruction(addr, se);
        entry->insertFront(alloca);                           
        se->setAddr(addr); 
        if (se->isParam()) {
            BasicBlock* bb = builder->getInsertBB();
            ((IdentifierSymbolEntry*)se)->setParamAddr(id->getOperand());
            new StoreInstruction(addr, se->getParamAddr(), bb);
        }  
        if(expr){
            BasicBlock* bb = builder->getInsertBB();
            expr->genCode();
            Operand* src = expr->getOperand();
            new StoreInstruction(addr, src, bb);
        }                                 
    }
}
void ReturnStmt::genCode()
{
    // Todo
    BasicBlock* bb = builder->getInsertBB();
    Operand* src = NULL;
    if (retValue) {
        retValue->genCode();
        src = retValue->getOperand();
    }
    new RetInstruction(src, bb);
}
void ExprStmt::genCode() {
    expr->genCode();
}
void ContinueStmt::genCode() {
    Function* func = builder->getInsertBB()->getParent();
    BasicBlock* bb = builder->getInsertBB();
    //跳转到判断条件处
    new UncondBrInstruction(((WhileStmt*)whileStmt)->getcond_bb(), bb);
    //含有跳转语句，新建基本块
    BasicBlock* continue_next_bb = new BasicBlock(func);
    builder->setInsertBB(continue_next_bb);
}
void BreakStmt::genCode() {
    Function* func = builder->getInsertBB()->getParent();
    BasicBlock* bb = builder->getInsertBB();
    //跳转到结尾处
    new UncondBrInstruction(((WhileStmt*)whileStmt)->getend_bb(), bb);
    BasicBlock* break_next_bb = new BasicBlock(func);
    builder->setInsertBB(break_next_bb);
}
void WhileStmt::genCode() {
    Function* func;
    BasicBlock *cond_bb, *stmt_bb, *end_bb, *bb;
    bb = builder->getInsertBB();
    func = builder->getInsertBB()->getParent();
    //新建的while循环需要的块
    cond_bb = new BasicBlock(func);
    stmt_bb = new BasicBlock(func);
    end_bb = new BasicBlock(func);
    //存储以便continue，break使用
    this->cond_bb = cond_bb;
    this->end_bb = end_bb;
    //bb的最后一条指令
    new UncondBrInstruction(cond_bb, bb);
    //设置为cond
    builder->setInsertBB(cond_bb);
    cond->genCode();
    //回填真假分支
    backPatch(cond->trueList(), stmt_bb);
    backPatch(cond->falseList(), end_bb);

    builder->setInsertBB(stmt_bb);
    //获取当前的块（保证获取的块最后一条不是跳转），因为可能生成代码过程中发生了跳转
    stmt->genCode();
    stmt_bb = builder->getInsertBB();
    new UncondBrInstruction(cond_bb, stmt_bb);
    /**
    ExprNode* cond1 = cond->copy();
    cond1->genCode();
    backPatch(cond1->trueList(), stmt_bb);
    backPatch(cond1->falseList(), end_bb);
    **/
    builder->setInsertBB(end_bb);
}
void NullStmt::genCode() {

}
void CallExpr::genCode() {
    std::vector<ExprNode*> paramlist=params->getparams();
    std::vector<Operand*> operands;
    for(int i =0;i<paramlist.size();i++){
        paramlist[i]->genCode();
        operands.push_back(paramlist[i]->getOperand());
    }
    BasicBlock* bb = builder->getInsertBB();
    new CallInstruction(dst, symbolEntry, operands, bb);
}
void UnaryExpr::genCode() {
    // Todo
    expr->genCode();
    if (op == NOT) {
        BasicBlock* bb = builder->getInsertBB();
        Operand* src = expr->getOperand();
        if (expr->getse()->getType()->isFloat() ||
            expr->getse()->getType()->isInt()) {  // FIXME: not i1
            Operand* temp = new Operand(new TemporarySymbolEntry(
                TypeSystem::boolType, SymbolTable::getLabel()));
            new CmpInstruction(
                CmpInstruction::NE, temp, src,
                new Operand(new ConstantSymbolEntry(TypeSystem::intType, 0)),
                bb);
            src = temp;
        }
        new XorInstruction(dst, src, bb);
    } else if (op == SUB) {
        Operand* src2;
        BasicBlock* bb = builder->getInsertBB();
        Operand* src1 = new Operand(new ConstantSymbolEntry(dst->getType(), 0));
        if (((IntType*)(expr->getse()->getType()))->getsize() == 1) {
            src2 = new Operand(new TemporarySymbolEntry(
                TypeSystem::intType, SymbolTable::getLabel()));
            new ZextInstruction(src2, expr->getOperand(), bb);
        } else
            src2 = expr->getOperand();
        new BinaryInstruction(BinaryInstruction::SUB, dst, src1, src2, bb);
    }
}
void ImplicitCastExpr::genCode() {
    expr->genCode();
    BasicBlock* bb = builder->getInsertBB();
    if (type == TypeSystem::boolType) {  // comparing ptr, should be ok here.
        Function* func = bb->getParent();
        BasicBlock* trueBB = new BasicBlock(func);
        BasicBlock* tempbb = new BasicBlock(func);
        BasicBlock* falseBB = new BasicBlock(func);

        new CmpInstruction(
            CmpInstruction::NE, this->dst, this->expr->getOperand(),
            new Operand(new ConstantSymbolEntry(TypeSystem::intType, 0)), bb);
        this->trueList().push_back(
            new CondBrInstruction(trueBB, tempbb, this->dst, bb));
        this->falseList().push_back(new UncondBrInstruction(falseBB, tempbb));
    } else if (type->isInt()) {
        new FptosiInstruction(dst, this->expr->getOperand(), bb);
    } else if (type->isFloat()) {
        new SitofpInstruction(dst, this->expr->getOperand(), bb);
    } 
}
void ExprNode::genCode() {

}
void CompoundStmt::genCode() {
    if (stmt)
        stmt->genCode();
}

void SeqNode::genCode() {
    stmt1->genCode();
    stmt2->genCode();
}
void AssignStmt::genCode()
{
    BasicBlock *bb = builder->getInsertBB();
    expr->genCode();
    Operand *addr = dynamic_cast<IdentifierSymbolEntry*>(lval->getSymPtr())->getAddr();
    Operand *src = expr->getOperand();
    /***
     * We haven't implemented array yet, the lval can only be ID. So we just store the result of the `expr` to the addr of the id.
     * If you want to implement array, you have to caculate the address first and then store the result into it.
     */
    new StoreInstruction(addr, src, bb);
}

void Ast::typeCheck()
{
    if(root != nullptr)
        root->typeCheck();
}

void FunctionDef::typeCheck()
{
    // Todo
}

void BinaryExpr::typeCheck()
{
    // Todo
}

void Constant::typeCheck()
{
    // Todo
}

void Id::typeCheck()
{
    // Todo
}

void IfStmt::typeCheck()
{
    // Todo
}

void IfElseStmt::typeCheck()
{
    // Todo
}

void CompoundStmt::typeCheck()
{
    // Todo
}

void SeqNode::typeCheck()
{
    // Todo
}

void DeclStmt::typeCheck()
{
    // Todo
}

void ReturnStmt::typeCheck()
{
    // Todo
}

void AssignStmt::typeCheck()
{
    // Todo
}

void BinaryExpr::output(int level)
{
    std::string op_str;
    switch(op)
    {
        case ADD:
            op_str = "add";
            break;
        case SUB:
            op_str = "sub";
            break;
        case AND:
            op_str = "and";
            break;
        case OR:
            op_str = "or";
            break;
        case LESS:
            op_str = "less";
            break;
        case MUL:
            op_str = "mul";
            break;
        case DIV:
            op_str = "div";
            break;
        case MOD:
            op_str = "mod";
            break;
        case LESSEQUAL:
            op_str = "lessequal";
            break;
        case GREATER:
            op_str = "greater";
            break;
        case GREATEREQUAL:
            op_str = "greaterequal";
            break;
        case EQUAL:
            op_str = "equal";
            break;
        case NOTEQUAL:
            op_str = "notequal";
            break;
    }
    fprintf(yyout, "%*c%s\n", level,' ',symbolEntry->toStr().c_str());
    fprintf(yyout, "%*cBinaryExpr\top: %s\n", level, ' ', op_str.c_str());
    expr1->output(level + 4);
    expr2->output(level + 4);
}

void Ast::output()
{
    fprintf(yyout, "program\n");
    if(root != nullptr)
        root->output(4);
}
void ImplicitCastExpr::output(int level) {
    fprintf(yyout, "%*cImplicitCastExpr\ttype: %s to %s\n", level, ' ',
            expr->getse()->getType()->toStr().c_str(), type->toStr().c_str());
    this->expr->output(level + 4);
}

void UnaryExpr::output(int level) {
    std::string op_str;
    switch (op) {
        case NOT:
            op_str = "not";
            break;
        case SUB:
            op_str = "negation";
            break;
    }
    fprintf(yyout, "%*cUnaryExpr\top: %s\n", level, ' ',
            op_str.c_str());
    expr->output(level + 4);
}
void Constant::output(int level)
{
    std::string type, value;
    type = symbolEntry->getType()->toStr();
    value = symbolEntry->toStr();
    fprintf(yyout, "%*cIntegerLiteral\tvalue: %s\ttype: %s\n", level, ' ',
            value.c_str(), type.c_str());
}
void MultExpNode::output(int level)
{
    fprintf(yyout, "%*cMultExpNode\n", level, ' ');
    int i =0;
    int num =paramlist.size();
    for(;i<num;i++){
    	if(paramlist[i])
    		paramlist[i]->output(level + 4);
    	else
    		fprintf(yyout, "%*c函数的数组参数第一维缺省\n", level+4, ' ');
    }
}
void ArrUseExpr::output(int level)
{
    fprintf(yyout, "%*cArrUseExpr\n", level, ' ');
    std::string name, type;
    int scope;
    name = symbolEntry->toStr();
    type = symbolEntry->getType()->toStr();
    scope = dynamic_cast<IdentifierSymbolEntry*>(symbolEntry)->getScope();
    fprintf(yyout, "%*cId\tname: %s\tscope: %d\ttype: %s\n", level+4, ' ',
            name.c_str(), scope, type.c_str());
    ((ArrayType*)(symbolEntry->getType()))->output(level+8);
    if(params) params->output(level+12);
}
void CallExpr::output(int level)
{
    fprintf(yyout, "%*cCallExpr\n", level, ' ');
    std::string name, type;
    int scope;
    name = symbolEntry->toStr();
    type = symbolEntry->getType()->toStr();
    scope = dynamic_cast<IdentifierSymbolEntry*>(symbolEntry)->getScope();
    fprintf(yyout, "%*cId\tname: %s\tscope: %d\ttype: %s\n", level+4, ' ',
            name.c_str(), scope, type.c_str());
    if(params) params->output(level+8);
}
void Id::output(int level)
{
    std::string name, type;
    int scope;
    name = symbolEntry->toStr();
    type = symbolEntry->getType()->toStr();
    scope = dynamic_cast<IdentifierSymbolEntry*>(symbolEntry)->getScope();
    fprintf(yyout, "%*cId\tname: %s\tscope: %d\ttype: %s\n", level, ' ',
            name.c_str(), scope, type.c_str());
    if(((ArrayType*)(symbolEntry->getType()))->isArr())
    	((ArrayType*)(symbolEntry->getType()))->output(level+4);
}
void NullStmt::output(int level){
    fprintf(yyout, "%*cNullStmt\n", level, ' ');
}
void ExprStmt::output(int level){
    fprintf(yyout, "%*cExprStmt\n", level, ' ');
    expr->output(level + 4);
}
void WhileStmt::output(int level) {
    fprintf(yyout, "%*cWhileStmt\n", level, ' ');
    cond->output(level + 4);
    stmt->output(level + 4);
}
void BreakStmt::output(int level) {
    fprintf(yyout, "%*cBreakStmt\n", level, ' ');
}

void ContinueStmt::output(int level) {
    fprintf(yyout, "%*cContinueStmt\n", level, ' ');
}

void CompoundStmt::output(int level)
{
    fprintf(yyout, "%*cCompoundStmt\n", level, ' ');
    if(stmt) stmt->output(level + 4);
}

void SeqNode::output(int level)
{
    //fprintf(yyout, "%*cSequence\n", level, ' ');
    stmt1->output(level);
    stmt2->output(level);
}

void DeclStmt::output(int level)
{
    fprintf(yyout, "%*cDeclStmt\n", level, ' ');
    int i =0;
    int num =deflist.size();
    for(;i<num;i++){
    	deflist[i]->output(level + 4);
    }
}
void DeclStmt::settype(std::vector<Type*>* type ){
    int i =0;
    int num =deflist.size();
    for(;i<num;i++){
    	type->push_back(((DefStmt*)(deflist[i]))->getid()->getse()->getType());
    }
}
void DeclStmt::setse(std::vector<SymbolEntry*>* se ){
    int i =0;
    int num =deflist.size();
    for(;i<num;i++){
    	se->push_back(((DefStmt*)(deflist[i]))->getid()->getse());
    }
}
void DefStmt::output(int level)
{
    fprintf(yyout, "%*cDefStmt\n", level, ' ');
    id->output(level+4);
    if(expr)
    	expr->output(level+4);
}
void IfStmt::output(int level)
{
    fprintf(yyout, "%*cIfStmt\n", level, ' ');
    cond->output(level + 4);
    thenStmt->output(level + 4);
}

void IfElseStmt::output(int level)
{
    fprintf(yyout, "%*cIfElseStmt\n", level, ' ');
    cond->output(level + 4);
    thenStmt->output(level + 4);
    elseStmt->output(level + 4);
}

void ReturnStmt::output(int level)
{
    fprintf(yyout, "%*cReturnStmt\n", level, ' ');
    retValue->output(level + 4);
}

void AssignStmt::output(int level)
{
    fprintf(yyout, "%*cAssignStmt\n", level, ' ');
    lval->output(level + 4);
    expr->output(level + 4);
}

void FunctionDef::output(int level)
{
    std::string name, type;
    name = se->toStr();
    type = se->getType()->toStr();
    fprintf(yyout, "%*cFunctionDefine function name: %s, type: %s\n", level, ' ', 
            name.c_str(), type.c_str());
    if(decl) decl->output(level + 4);
    stmt->output(level + 4);
}
