#ifndef __TYPE_H__
#define __TYPE_H__
#include <vector>
#include <string>
//#include "Ast.h"
class SymbolEntry;
class MultExpNode;
class Type 
{
private:
    int kind;
protected:
    enum {INT, VOID, FUNC, PTR,FLOAT,ARRAY,STRING};
public:
    Type(int kind) : kind(kind) {};
    virtual ~Type() {};
    virtual std::string toStr() = 0;
    bool isInt() const {return kind == INT;};
    bool isVoid() const {return kind == VOID;};
    bool isFunc() const {return kind == FUNC;};
    bool isFloat() const {return kind == FLOAT;};
    bool isArr() const {return kind == ARRAY;};
    bool isStr() const {return kind == STRING;};
};

class IntType : public Type
{
private:
    int size;
    bool constval;
public:
    IntType(int size,bool constval=false) : Type(Type::INT), size(size),constval(constval){};
    std::string toStr();
    bool isconst() const{return constval;};
    int getsize() {return size;};
};

class VoidType : public Type
{
public:
    VoidType() : Type(Type::VOID){};
    std::string toStr();
};
class ArrayType: public Type{
private:
    Type* type;
//各维度应该是用len来存储，但是现在还不知道怎么计算值（因为是常量表达式所有的都是常值，所以根据节点关系直接算？遇到常数用constant，遇到id判断是不是constant？在常量id赋值的时候直接算？)
    MultExpNode* dim;
public:
    ArrayType(Type* type,MultExpNode* dim):Type(Type::ARRAY),type(type),dim(dim){};
    std::string toStr();
    void output(int level);
};
class FunctionType : public Type
{
private:
    Type *returnType;
    std::vector<Type*> paramsType;
    std::vector<SymbolEntry*> paramsSe;
public:
    FunctionType(Type* returnType, std::vector<Type*> paramsType,std::vector<SymbolEntry*> paramsSe) : 
    Type(Type::FUNC), returnType(returnType), paramsType(paramsType),paramsSe(paramsSe){};
    Type* getRetType() {return returnType;};
    std::vector<Type*> getParams(){return paramsType;};
    std::vector<SymbolEntry*> getParamsSe(){return paramsSe;};
    std::string toStr();
};
class FloatType : public Type {
private:
    int size;
    bool constval;  
public:
    FloatType(int size,bool constval=false)
        : Type(Type::FLOAT), size(size),constval(constval){};
    std::string toStr();
    bool isConst() const { return constval; };
    int getsize() {return size;};
};
class PointerType : public Type
{
private:
    Type *valueType;
public:
    PointerType(Type* valueType) : Type(Type::PTR) {this->valueType = valueType;};
    std::string toStr();
};

class TypeSystem
{
private:
    static IntType commonInt;
    static IntType commonBool;
    static VoidType commonVoid;
    static FloatType commonFloat;
    static IntType commonconstInt;
    static FloatType commonconstFloat;
public:
    static Type *intType;
    static Type *voidType;
    static Type *boolType;
    static Type *floatType;
    static Type *constfloatType;
    static Type *constintType;
};

#endif
